# Fallback Model Test Summary

**Test Date:** 2025-10-05 13:17:05
**Total Models Tested:** 9
**Working Models:** 9
**Failed Models:** 0

## Working Models ✅

- **openrouter/deepseek/deepseek-chat**
- **openrouter/deepseek/deepseek-chat-v3**
- **openrouter/tngtech/deepseek-r1t2-chimera:free**
- **openrouter/z-ai/glm-4.5-air:free**
- **openrouter/tngtech/deepseek-r1t-chimera:free**
- **openrouter/microsoft/mai-ds-r1:free**
- **openrouter/qwen/qwen3-235b-a22b:free**
- **openrouter/google/gemini-2.0-flash-exp:free**
- **openrouter/meta-llama/llama-3.3-70b-instruct:free**

## Failed Models ❌


## Detailed Results

### openrouter/deepseek/deepseek-chat
- **Status:** WORKING
- **Success Rate:** 4/4

### openrouter/deepseek/deepseek-chat-v3
- **Status:** WORKING
- **Success Rate:** 4/4

### openrouter/tngtech/deepseek-r1t2-chimera:free
- **Status:** WORKING
- **Success Rate:** 4/4

### openrouter/z-ai/glm-4.5-air:free
- **Status:** WORKING
- **Success Rate:** 4/4

### openrouter/tngtech/deepseek-r1t-chimera:free
- **Status:** WORKING
- **Success Rate:** 4/4

### openrouter/microsoft/mai-ds-r1:free
- **Status:** WORKING
- **Success Rate:** 3/4

### openrouter/qwen/qwen3-235b-a22b:free
- **Status:** WORKING
- **Success Rate:** 4/4

### openrouter/google/gemini-2.0-flash-exp:free
- **Status:** WORKING
- **Success Rate:** 4/4

### openrouter/meta-llama/llama-3.3-70b-instruct:free
- **Status:** WORKING
- **Success Rate:** 4/4

